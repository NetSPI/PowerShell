﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CryptIt;

namespace project2
{
    class Program
    {
        static void Main(string[] args)
        {
            //-------------------------------------------------------------------	
            // Encrypt/Decrypt file with AES password recusively
            //-------------------------------------------------------------------	

            // Run encryption            
            EncryptionFunctions.DirFileEncryptRec2("c:\\temp", "MyPassword123", ".enc", "Yes", 1000, "1");
            EncryptionFunctions.DirFileEncryptRec2("c:\\temp", "MyPassword123", ".enc", "No", 1000, "0");
            
            // syntax	
            //CryptFilesRecusive(string targetFilepath, string aesPassword, string fileExt, string genFiles, int Filenumb, string cryptMode)

            // Run encryption            
            //EncryptionFunctions.DirFileEncryptRec1("c:\\temp", "MyPassword123", ".enc", "Yes", 1000, "1");

            // Run decryptions
            //EncryptionFunctions.DirFileEncryptRec1("c:\\temp", "MyPassword123", ".enc", "No", 1000, "0");

            //-------------------------------------------------------------------	
            // Encrypt/Decrypt file with cert example
            //-------------------------------------------------------------------	

            // Create a mock AES key file
            Console.WriteLine("Creating mock aeskeyfile.txt");
            string path = "c:\\temp\\aeskeyfile.txt";
            using (FileStream fs = File.Create(path))
            {
                byte[] info = new System.Text.UTF8Encoding(true).GetBytes("EAAAAO/kwWaRfvX6MtvpNx/5HkJg4tqB2AZhs34IKkJUvJzU");

                fs.Write(info, 0, info.Length);
            }

            // Generate new public/private key pair
            Console.WriteLine("Creating public/private key pair");
            EncryptionFunctions.GenerateKeys("c:\\temp\\public.key", "c:\\temp\\private.key");

            // Encrypt file with public key
            //Encrypt(string publicKeyFileName, string plainFileName, string encryptedFileName)            
            Console.WriteLine("Encrypting a file with a public key");
            EncryptionFunctions.EncryptWithKey("c:\\temp\\public.key", "c:\\temp\\aeskeyfile.txt", "c:\\temp\\aeskeyfile.txt.enc");

            // Decrypt file with private key
            // Decrypt(string privateKeyFileName, string encryptedFileName, string plainFileName)            
            Console.WriteLine("Decrypting a file with a private key");
            EncryptionFunctions.DecryptWithKey("c:\\temp\\private.key", "c:\\temp\\aeskeyfile.txt.enc", "c:\\temp\\aeskeyfile.txt.dec");

            //-------------------------------------------------------------------	
            // Encrypt/Decrypt data with AES password example
            //-------------------------------------------------------------------	

            //Console.WriteLine("Encrypting string: Encrypt this string.");
            var enctext = EncryptionFunctions.EncryptStringAES("Encrypt this string.", "mypassword");
            Console.WriteLine(enctext);

            //Console.WriteLine("Decrypting string: {0}", enctext);
            var dectext = EncryptionFunctions.DecryptStringAES(enctext, "mypassword");
            Console.WriteLine(dectext);
            
        }
    }
}
